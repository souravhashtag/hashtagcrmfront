import React, { useState } from 'react';
import {
  FaThLarge,
  FaUserFriends,
  FaBusinessTime,
  FaCalendarCheck,
  FaMoneyBill,
  FaBriefcase,
  FaUserTie,
  FaClipboardList,
  FaCalendarAlt,
  FaCog,
  FaSun,
  FaMoon,
} from 'react-icons/fa';
import type { IconType } from 'react-icons';

type MenuItem = {
  name: string;
  icon: IconType;
};

const Sidebar = (): React.ReactElement => {
  const [active, setActive] = useState<string>('Dashboard');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const handleThemeToggle = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
  };

  const menuItems: MenuItem[] = [
    { name: 'Dashboard', icon: FaThLarge },
    { name: 'All Employees', icon: FaUserFriends },
    { name: 'All Departments', icon: FaBusinessTime },
    { name: 'Attendance', icon: FaCalendarCheck },
    { name: 'Payroll', icon: FaMoneyBill },
    { name: 'Jobs', icon: FaBriefcase },
    { name: 'Candidates', icon: FaUserTie },
    { name: 'Leaves', icon: FaClipboardList },
    { name: 'Holidays', icon: FaCalendarAlt },
    { name: 'Settings', icon: FaCog },
  ];

  return (
    <div className="sidebar">
      <div className="logo">
        <img src="/logo.png" alt="Hashtag Biz Logo" />
      </div>

      <ul className="nav">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <li
              key={item.name}
              className={active === item.name ? 'active' : ''}
              onClick={() => setActive(item.name)}
              style={{ cursor: 'pointer' }}
            >
              <span className="icon">
                {/* <Icon /> */}
              </span>
              {item.name}
            </li>
          );
        })}
      </ul>
{/* 
      <div className="theme-toggle">
        <button
          className={theme === 'light' ? 'light active' : 'light'}
          onClick={() => handleThemeToggle('light')}
          aria-pressed={theme === 'light'}
        >
          <FaSun /> Light
        </button>
        <button
          className={theme === 'dark' ? 'dark active' : 'dark'}
          onClick={() => handleThemeToggle('dark')}
          aria-pressed={theme === 'dark'}
        >
          <FaMoon /> Dark
        </button>
      </div> */}
    </div>
  );
};

export default Sidebar;
